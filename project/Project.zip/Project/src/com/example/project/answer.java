package com.example.project;

import android.app.Activity;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;

public class answer extends Activity{
	private MySQLiteHelper mySQLiteHelper;
	private SQLiteDatabase db;
	 MySQLiteHelper mySQLiteHelper1 = new MySQLiteHelper(answer.this,"question.db", 
     		null, 1);
	 protected void onCreate(Bundle savedInstanceState) {
	        super.onCreate(savedInstanceState);
	        
	 }
}
