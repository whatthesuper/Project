package com.example.project;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Button;

public class first extends Activity{
	  private Button btn; 
	@Override
	    protected void onCreate(Bundle savedInstanceState) {
		
	  }
}
